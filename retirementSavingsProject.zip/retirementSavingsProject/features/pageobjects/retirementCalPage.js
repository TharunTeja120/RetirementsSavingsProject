

class retirementCalPage {

    get startCal() { return $("//a[contains(text(),'Start calculating')]") }
    get currentAge() { return $("//input[@id='current-age']") }
    get agePlan() { return $("//input[@id='retirement-age']") }
    get currentAnnualIncome() { return $("//input[@id='current-income']") }
    get spuseIncome() { return $("//input[@id='spouse-income']") }

    get currentTotalSavings() { return $("//input[@id='current-total-savings']") }

    get currentAnnualSavings() { return $("//input[@id='current-annual-savings']") }

    get savingsIncreaseRate() { return $("//input[@id='savings-increase-rate']") }

    get yesSocialBen() { return $("//label[@for='yes-social-benefits']") }

    get noSocialBen() { return $("//label[@for='no-social-benefits']") }

    get single() { return $("//label[@for='single']") }

    get savingsIncreaseRateoverride() { return $("//input[@id='social-security-override']") }

    get calculateBtn() { return $("//button[text()='Calculate' and @type='button']") }
    get resultsChart() { return $("//canvas[@id='results-chart']") }

    get defCalVal() { return $("//a[contains(text(),'Adjust default values')]") }

    get addIncome() { return $("//input[@id='additional-income']") }

    get retireDuration() { return $("//input[@id='retirement-duration']") }

    get retAnnualIncome() { return $("//input[@id='retirement-annual-income']") }

    get preRetirement() { return $("//input[@id='pre-retirement-roi']") }

    get postRetirement() { return $("//input[@id='post-retirement-roi']") }

    get saveChanges() { return $("//button[text()='Save changes']") }

    get resultsPage() { return $("//div[@id='calculator-results-container']") }

    get socialSecToggles() { return $("//fieldset[@id='marital-status-toggle-group']") }

    get socialSecTogglesnotDisplayed() { return $("//div[@class='row social-security-field' and @style='display: none;'][1]") }

    errorMsg(str) { return $("//span[@class='invalid-error' and @id=" + "'" + str + "'" + "]") }



}


module.exports = new retirementCalPage()
