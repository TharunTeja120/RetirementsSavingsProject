const { Given, When, Then } = require('@wdio/cucumber-framework');


const page = require('../pageobjects/page');
// const SecurePage = require('../pageobjects/secure.page');

const retirement = require('../pageobjects/retirementCalPage');



Given('Navigate To Respective page', async function () {
    page.opensecurian();
    browser.maximizeWindow();
    page.waitforPageLoad()
    await retirement.startCal.waitForDisplayed({ timeout: 30000 });
    await retirement.startCal.click();

});

When('User fills all the data in the calulator page', async function (dataTable) {
    page.waitforPageLoad()

    let input = dataTable.hashes();
    await retirement.currentAge.waitForDisplayed({ timeout: 20000 });
    await retirement.currentAge.click();
    await retirement.currentAge.setValue(input[0].requestValue);
    await retirement.agePlan.click();
    await retirement.agePlan.setValue(input[1].requestValue);
    await retirement.currentAnnualIncome.click();
    await retirement.currentAnnualIncome.setValue(input[2].requestValue);
    await retirement.spuseIncome.click();
    await retirement.spuseIncome.setValue(input[3].requestValue)
    await retirement.currentTotalSavings.click();
    await retirement.currentTotalSavings.setValue(input[4].requestValue);
    await retirement.currentAnnualSavings.click();
    await retirement.currentAnnualSavings.setValue(input[5].requestValue);
    await retirement.savingsIncreaseRate.click();
    await retirement.savingsIncreaseRate.setValue(input[6].requestValue);
    await retirement.yesSocialBen.click();
    await retirement.single.waitForDisplayed({ timeout: 4000 });
    await retirement.single.click();
    await retirement.savingsIncreaseRateoverride.click();
    await retirement.savingsIncreaseRateoverride.setValue(input[7].requestValue);
    console.log("CALCULATION DONE");

});

Then('User should see the calculator Results Page', async function () {
    page.waitforPageLoad()
    await retirement.resultsPage.waitForDisplayed({ timeout: 10000 });
    await retirement.resultsChart.isDisplayed();
});

Then('User should check the social secuerity Toggles', async function () {
    page.waitforPageLoad()
    await retirement.yesSocialBen.waitForDisplayed({ timeout: 3000 })
    await retirement.yesSocialBen.click();
    await retirement.socialSecToggles.isDisplayed();
    await retirement.noSocialBen.click();
    await browser.pause(2000)
    await expect(retirement.socialSecTogglesnotDisplayed).toExist()

});


Then('User should validate the error Messages {string} of the text fields by inputID {string}', async function (errorMsg, id) {
    await retirement.currentAge.waitForDisplayed({ timeout: 20000 });
    await retirement.errorMsg(id).waitForDisplayed({ timeout: 10000 });
    await expect(retirement.errorMsg(id)).toHaveText(errorMsg)
});

Then('User clicks on element Calculate Btn', async function () {
    await retirement.calculateBtn.click();

});
Then('User clicks on element adjust Default val Btn', async function () {
    await retirement.defCalVal.waitForDisplayed();
    await retirement.defCalVal.click();

});

When('User fills all the data in the default calulator pop up', async function (dataTable) {
    page.waitforPageLoad()
    let input = dataTable.hashes();
    await browser.pause(2000)
    await retirement.addIncome.waitForDisplayed({ timeout: 20000 });
    await retirement.addIncome.click();
    await retirement.addIncome.setValue(input[0].requestValue);
    await retirement.retireDuration.click();
    await retirement.retireDuration.setValue(input[1].requestValue);
    await retirement.retAnnualIncome.click();
    await retirement.retAnnualIncome.setValue(input[2].requestValue);
    await retirement.preRetirement.click();
    await retirement.preRetirement.setValue(input[3].requestValue)
    await retirement.postRetirement.click();
    await retirement.postRetirement.setValue(input[4].requestValue);
    await retirement.saveChanges.click();
    console.log("Default calculator values DONE");

});